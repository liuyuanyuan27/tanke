﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine; //引用命名空间

public class PlayContrl : MonoBehaviour   //一个类
{
    private Rigidbody2D heroBody;  //定义一个heroBody的刚体
    public float force=5 ;        //定义了一个公共变量
    // Start is called before the first frame update
    void Start()
    {
        heroBody = GetComponent<Rigidbody2D>();//获取herobody 对象
    }

    // Update is called once per frame
    void Update()
    {
        float h = Input.GetAxis("Horizontal");  //声明一个浮点型变量，获取到输入的水平方向的轴
     //   if()
        heroBody.AddForce(Vector2.right *h* force * 15);//给刚体赋力量值一个向量向右的值。
    }
}
